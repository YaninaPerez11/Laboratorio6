﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Laboratorio6.Entidad;
using Laboratorio6.Logica;

namespace Laboratorio6
{
    public partial class Form1 : Form
    {
        private readonly LogicaLibros libroLogica;

        public Form1()
        {
            InitializeComponent();
            libroLogica = new LogicaLibros();
            BackgroundImage = Properties.Resources.Fondo6;
            BackgroundImageLayout = ImageLayout.Stretch;
            Text = "Biblioteca - Inventario de libros";
            txtBuscarLibro.MaxLength = 200;
            dgvLibros.AutoGenerateColumns = true;
            dgvLibros.ReadOnly = true;
            dgvLibros.AllowUserToAddRows = false;
            dgvLibros.AllowUserToDeleteRows = false;
            dgvLibros.MultiSelect = false;
            dgvLibros.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvLibros.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            // Se enlazan los eventos de los controles existentes.
            Shown += Form1_Shown;
            btnAgregarLibro.Click += BtnAgregarLibro_Click;
            btnActualizarCantidad.Click += BtnActualizarCantidad_Click;
            btnEliminar.Click += BtnEliminar_Click;
            btnBuscarLibro.Click += BtnBuscarLibro_Click;
            btnRecargar.Click += BtnRecargar_Click;
            txtBuscarLibro.KeyDown += TxtBuscarLibro_KeyDown;
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            CargarLibros();
        }

        private bool CargarLibros()
        {
            try
            {
                dgvLibros.DataSource = libroLogica.ObtenerLibros(txtBuscarLibro.Text);
                FormatearColumnas();
                dgvLibros.ClearSelection();
                dgvLibros.CurrentCell = null;
                return true;
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(this, ex.Message, "Error de validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (InvalidOperationException ex)
            {
                dgvLibros.DataSource = null;
                MessageBox.Show(this, ex.Message, "Error de base de datos",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return false;
        }

        private void FormatearColumnas()
        {
            dgvLibros.Columns["id"].HeaderText = "Código";
            dgvLibros.Columns["id"].FillWeight = 35;
            dgvLibros.Columns["Titulo"].HeaderText = "Título";
            dgvLibros.Columns["Autor"].HeaderText = "Autor";
            dgvLibros.Columns["CantidadDisponible"].HeaderText = "Ejemplares disponibles";
            dgvLibros.Columns["Categoria"].HeaderText = "Categoría";
        }

        private Libro ObtenerSeleccionado()
        {
            if (dgvLibros.SelectedRows.Count == 0)
            {
                MessageBox.Show(this, "Selecciona primero una fila del inventario.", "Seleccionar libro",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }
            DataRowView fila = dgvLibros.SelectedRows[0].DataBoundItem as DataRowView;
            if (fila == null)
            {
                return null;
            }
            Libro libro = new Libro(Convert.ToString(fila["Titulo"]), Convert.ToString(fila["Autor"]),
                Convert.ToInt32(fila["CantidadDisponible"]), Convert.ToString(fila["Categoria"]));
            libro.Id = Convert.ToInt32(fila["id"]);
            return libro;
        }

        private void BtnAgregarLibro_Click(object sender, EventArgs e)
        {
            using (Form2 registro = new Form2())
            {
                if (registro.ShowDialog(this) == DialogResult.OK)
                {
                    txtBuscarLibro.Clear();
                    CargarLibros();
                }
            }
        }

        private void BtnActualizarCantidad_Click(object sender, EventArgs e)
        {
            Libro libro = ObtenerSeleccionado();
            if (libro == null)
            {
                return;
            }
            using (Form2 edicion = new Form2(libro))
            {
                if (edicion.ShowDialog(this) == DialogResult.OK)
                {
                    CargarLibros();
                }
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            Libro libro = ObtenerSeleccionado();
            if (libro == null)
            {
                return;
            }
            DialogResult respuesta = MessageBox.Show(this,
                "¿Deseas eliminar el libro «" + libro.Titulo + "»?", "Confirmar eliminación",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (respuesta != DialogResult.Yes)
            {
                return;
            }
            try
            {
                libroLogica.EliminarLibro(libro.Id);
                MessageBox.Show(this, "Libro eliminado correctamente.", "Inventario de libros",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarLibros();
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(this, ex.Message, "Error de validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(this, ex.Message, "Error de base de datos",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnBuscarLibro_Click(object sender, EventArgs e)
        {
            if (CargarLibros() && dgvLibros.Rows.Count == 0)
            {
                MessageBox.Show(this, "No se encontraron libros con esa búsqueda.", "Buscar libros",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnRecargar_Click(object sender, EventArgs e)
        {
            txtBuscarLibro.Clear();
            CargarLibros();
        }

        private void TxtBuscarLibro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                BtnBuscarLibro_Click(sender, e);
            }
        }
    }
}
