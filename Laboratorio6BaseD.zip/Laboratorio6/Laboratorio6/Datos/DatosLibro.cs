﻿using System;
using System.Data;
using System.Data.SqlClient;
using Laboratorio6.Entidad;

namespace Laboratorio6.Datos
{
    public class DatosLibro
    {
        private readonly Conexion conexionBD;

        public DatosLibro()
        {
            conexionBD = new Conexion();
        }

        public DataTable ObtenerLibros(string busqueda)
        {
            try
            {
                using (SqlConnection conexion = conexionBD.CrearConexion())
                using (SqlCommand comando = new SqlCommand("dbo.usp_Libros_Listar", conexion))
                {
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.Parameters.Add("@Busqueda", SqlDbType.NVarChar, 200).Value = busqueda;
                    using (SqlDataAdapter adaptador = new SqlDataAdapter(comando))
                    {
                        DataTable tabla = new DataTable();
                        adaptador.Fill(tabla);
                        return tabla;
                    }
                }
            }
            catch (SqlException ex)
            {
                throw new InvalidOperationException("No se pudo consultar el inventario. Comprueba la conexión y los procedimientos de Libreria.", ex);
            }
        }

        public int Insertar(Libro libro)
        {
            try
            {
                using (SqlConnection conexion = conexionBD.CrearConexion())
                using (SqlCommand comando = new SqlCommand("dbo.usp_Libros_Agregar", conexion))
                {
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.Parameters.Add("@Titulo", SqlDbType.NVarChar, 200).Value = libro.Titulo;
                    comando.Parameters.Add("@Autor", SqlDbType.NVarChar, 150).Value = libro.Autor;
                    comando.Parameters.Add("@CantidadDisponible", SqlDbType.Int).Value = libro.CantidadDisponible;
                    comando.Parameters.Add("@Categoria", SqlDbType.NVarChar, 50).Value = libro.Categoria;
                    conexion.Open();
                    object resultado = comando.ExecuteScalar();
                    if (resultado == null || resultado == DBNull.Value)
                        throw new InvalidOperationException("La base de datos no devolvió el código del libro. Revisa el inventario antes de volver a registrarlo.");
                    return Convert.ToInt32(resultado);
                }
            }
            catch (SqlException ex)
            {
                string mensaje = ex.Number >= 50000 ? ex.Message : "No se pudo registrar el libro. Comprueba la conexión y los procedimientos de Libreria.";
                throw new InvalidOperationException(mensaje, ex);
            }
        }

        public void ActualizarCantidad(int id, int cantidad)
        {
            try
            {
                using (SqlConnection conexion = conexionBD.CrearConexion())
                using (SqlCommand comando = new SqlCommand("dbo.usp_Libros_ActualizarCantidad", conexion))
                {
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                    comando.Parameters.Add("@CantidadDisponible", SqlDbType.Int).Value = cantidad;
                    conexion.Open();
                    comando.ExecuteNonQuery();
                }
            }
            catch (SqlException ex)
            {
                string mensaje = ex.Number >= 50000 ? ex.Message : "No se pudo actualizar la cantidad del libro. Comprueba la conexión a SQL Server.";
                throw new InvalidOperationException(mensaje, ex);
            }
        }

        public void Eliminar(int id)
        {
            try
            {
                using (SqlConnection conexion = conexionBD.CrearConexion())
                using (SqlCommand comando = new SqlCommand("dbo.usp_Libros_Eliminar", conexion))
                {
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                    conexion.Open();
                    comando.ExecuteNonQuery();
                }
            }
            catch (SqlException ex)
            {
                string mensaje = ex.Number >= 50000 ? ex.Message : "No se pudo eliminar el libro. Comprueba la conexión a SQL Server.";
                throw new InvalidOperationException(mensaje, ex);
            }
        }
    }
}
