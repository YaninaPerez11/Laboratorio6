using System;
using System.Drawing;
using System.Windows.Forms;
using Laboratorio6.Entidad;
using Laboratorio6.Logica;

namespace Laboratorio6
{
    public partial class Form2 : Form
    {
        private readonly LogicaLibros libroLogica;
        private readonly int idLibro;

        public Form2()
        {
            InitializeComponent();
            libroLogica = new LogicaLibros();
            BackgroundImage = Properties.Resources.Fondo6;
            BackgroundImageLayout = ImageLayout.Stretch;
            Text = "Biblioteca - Registrar libro";
            label1.Text = "Título del libro";
            txtTituloDeLibro.MaxLength = 200;
            txtAutor.MaxLength = 150;
            txtCantidad.Text = "0";
            cmbCategoria.SelectedIndex = -1;
            AcceptButton = btnGuardar;
            CancelButton = btnCancelar;

            Load += Form2_Load;
            btnGuardar.Click += BtnGuardar_Click;
            btnCancelar.Click += BtnCancelar_Click;
        }

        public Form2(Libro libro) : this()
        {
            if (libro == null)
            {
                throw new ArgumentNullException(nameof(libro));
            }

            idLibro = libro.Id;
            Text = "Biblioteca - Actualizar cantidad";
            label2.Text = "Actualizar cantidad";
            txtTituloDeLibro.Text = libro.Titulo;
            txtAutor.Text = libro.Autor;
            txtCantidad.Text = libro.CantidadDisponible.ToString();
            if (!cmbCategoria.Items.Contains(libro.Categoria))
            {
                cmbCategoria.Items.Add(libro.Categoria);
            }
            cmbCategoria.SelectedItem = libro.Categoria;
            txtTituloDeLibro.ReadOnly = true;
            txtAutor.ReadOnly = true;
            cmbCategoria.Enabled = false;
            Shown += delegate { txtCantidad.Focus(); txtCantidad.SelectAll(); };
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            cmbCategoria.DropDownStyle = ComboBoxStyle.DropDownList;
            txtTituloDeLibro.TextChanged += ValidarFormulario;
            txtAutor.TextChanged += ValidarFormulario;
            txtCantidad.TextChanged += ValidarFormulario;
            cmbCategoria.SelectedIndexChanged += ValidarFormulario;
            ValidarFormulario(sender, e);
        }

        // Igual que en el ejemplo: habilita Guardar cuando están los campos completos.
        // La revisión de los valores se realiza en LogicaLibros al intentar guardar.
        private void ValidarFormulario(object sender, EventArgs e)
        {
            bool cantidadCompleta = !string.IsNullOrWhiteSpace(txtCantidad.Text);
            if (idLibro > 0)
            {
                btnGuardar.Enabled = cantidadCompleta;
                return;
            }

            bool tituloCompleto = !string.IsNullOrWhiteSpace(txtTituloDeLibro.Text);
            bool autorCompleto = !string.IsNullOrWhiteSpace(txtAutor.Text);
            bool categoriaSeleccionada = cmbCategoria.SelectedIndex != -1;
            btnGuardar.Enabled = tituloCompleto && autorCompleto && cantidadCompleta && categoriaSeleccionada;
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                int cantidad = libroLogica.ValidarCantidad(txtCantidad.Text);
                if (idLibro > 0)
                {
                    libroLogica.ActualizarCantidad(idLibro, cantidad);
                    MessageBox.Show(this, "Cantidad actualizada correctamente.", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    Libro nuevoLibro = new Libro(txtTituloDeLibro.Text, txtAutor.Text,
                        cantidad, Convert.ToString(cmbCategoria.SelectedItem));
                    int codigo = libroLogica.InsertarLibro(nuevoLibro);
                    MessageBox.Show(this, "Libro registrado correctamente con el código " + codigo + ".",
                        "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                DialogResult = DialogResult.OK;
                Close();
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(this, ex.Message, "Error de validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCantidad.Focus();
                txtCantidad.SelectAll();
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(this, ex.Message, "Error de base de datos",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
