using System;
using System.Configuration;
using System.Data.SqlClient;

namespace Laboratorio6.Datos
{
    public class Conexion
    {
        private readonly string nombreCadena;

        public Conexion()
        {
            nombreCadena = "Libreria";
        }

        public SqlConnection CrearConexion()
        {
            try
            {
                ConnectionStringSettings configuracion = ConfigurationManager.ConnectionStrings[nombreCadena];
                if (configuracion == null || string.IsNullOrWhiteSpace(configuracion.ConnectionString))
                {
                    throw new InvalidOperationException("No se encontró la conexión Libreria en App.config.");
                }

                return new SqlConnection(configuracion.ConnectionString);
            }
            catch (ConfigurationErrorsException ex)
            {
                throw new InvalidOperationException("Revisa el formato del archivo App.config.", ex);
            }
            catch (ArgumentException ex)
            {
                throw new InvalidOperationException("La cadena de conexión Libreria no tiene un formato válido.", ex);
            }
        }
    }
}
