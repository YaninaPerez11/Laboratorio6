using System;
using System.Data;
using System.Globalization;
using Laboratorio6.Datos;
using Laboratorio6.Entidad;

namespace Laboratorio6.Logica
{
    public class LogicaLibros
    {
        private readonly DatosLibro libroDatos;
        private readonly string[] categoriasValidas;

        public LogicaLibros()
        {
            libroDatos = new DatosLibro();
            categoriasValidas = new string[]
            {
                "Novela", "Ciencia ficción", "Fantasía", "Historia", "Otros"
            };
        }

        public DataTable ObtenerLibros(string busqueda)
        {
            string texto = busqueda == null ? string.Empty : busqueda.Trim();

            if (texto.Length > 200)
            {
                throw new ArgumentException("La búsqueda no puede superar 200 caracteres.");
            }

            return libroDatos.ObtenerLibros(texto);
        }

        // Se revisa el texto original antes de convertirlo: no se redondea ni se corrige.
        public int ValidarCantidad(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
            {
                throw new ArgumentException("La cantidad de ejemplares es obligatoria.");
            }

            texto = texto.Trim();
            if (texto.Contains(".") || texto.Contains(","))
            {
                throw new ArgumentException("La cantidad debe ser un número entero, sin decimales ni separadores. Ejemplo: 5.");
            }

            int cantidad;
            if (!int.TryParse(texto, NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out cantidad))
            {
                throw new ArgumentException("Escribe una cantidad entera entre 0 y 2147483647, sin letras ni otros símbolos.");
            }

            ValidarCantidad(cantidad);
            return cantidad;
        }

        public int InsertarLibro(Libro libro)
        {
            if (libro == null)
            {
                throw new ArgumentNullException(nameof(libro), "Los datos del libro son obligatorios.");
            }

            ValidarDatos(libro.Titulo, libro.Autor, libro.CantidadDisponible, libro.Categoria);
            libro.Titulo = libro.Titulo.Trim();
            libro.Autor = libro.Autor.Trim();
            libro.Categoria = libro.Categoria.Trim();

            return libroDatos.Insertar(libro);
        }

        public void ActualizarCantidad(int id, int cantidad)
        {
            ValidarId(id);
            ValidarCantidad(cantidad);
            libroDatos.ActualizarCantidad(id, cantidad);
        }

        public void EliminarLibro(int id)
        {
            ValidarId(id);
            libroDatos.Eliminar(id);
        }

        private void ValidarDatos(string titulo, string autor, int cantidad, string categoria)
        {
            if (string.IsNullOrWhiteSpace(titulo))
            {
                throw new ArgumentException("El título del libro es obligatorio.");
            }

            if (titulo.Trim().Length > 200)
            {
                throw new ArgumentException("El título no puede superar 200 caracteres.");
            }

            if (string.IsNullOrWhiteSpace(autor))
            {
                throw new ArgumentException("El autor del libro es obligatorio.");
            }

            if (autor.Trim().Length > 150)
            {
                throw new ArgumentException("El autor no puede superar 150 caracteres.");
            }

            if (!CategoriaValida(categoria))
            {
                throw new ArgumentException("Selecciona una categoría válida.");
            }

            ValidarCantidad(cantidad);
        }

        private void ValidarId(int id)
        {
            if (id <= 0)
            {
                throw new ArgumentException("Selecciona un libro válido del inventario.");
            }
        }

        private void ValidarCantidad(int cantidad)
        {
            if (cantidad < 0)
            {
                throw new ArgumentException("La cantidad no puede ser negativa. Cero indica que el libro está agotado.");
            }
        }

        private bool CategoriaValida(string categoria)
        {
            if (string.IsNullOrWhiteSpace(categoria))
            {
                return false;
            }

            foreach (string opcion in categoriasValidas)
            {
                if (opcion.Equals(categoria.Trim(), StringComparison.Ordinal))
                {
                    return true;
                }
            }

            return false;
        }
    }
}
