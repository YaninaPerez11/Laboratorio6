-- Ejecutar completo en SQL Server Management Studio (SQL Server 2016 SP1 o posterior).
-- Crea la base si no existe. No elimina libros ni inserta datos de prueba.
USE master;
GO
IF DB_ID(N'Libreria') IS NULL
    EXEC(N'CREATE DATABASE Libreria');
GO
USE Libreria;
GO
IF OBJECT_ID(N'dbo.Libros', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Libros
    (
        id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Libros PRIMARY KEY,
        Titulo NVARCHAR(200) NOT NULL,
        Autor NVARCHAR(150) NOT NULL,
        CantidadDisponible INT NOT NULL CONSTRAINT CK_Libros_Cantidad CHECK (CantidadDisponible >= 0),
        Categoria NVARCHAR(50) NOT NULL CONSTRAINT DF_Libros_Categoria DEFAULT N'Otros',
        CONSTRAINT CK_Libros_Titulo CHECK (LEN(LTRIM(RTRIM(Titulo))) > 0),
        CONSTRAINT CK_Libros_Autor CHECK (LEN(LTRIM(RTRIM(Autor))) > 0)
    );
END;
GO
-- Compatibilidad con una tabla que ya tenga las cuatro columnas del enunciado.
IF COL_LENGTH(N'dbo.Libros', N'Categoria') IS NULL
    ALTER TABLE dbo.Libros ADD Categoria NVARCHAR(50) NOT NULL
        CONSTRAINT DF_Libros_Categoria DEFAULT N'Otros' WITH VALUES;
GO
CREATE OR ALTER PROCEDURE dbo.usp_Libros_Listar
    @Busqueda NVARCHAR(200) = N''
AS
BEGIN
    SET NOCOUNT ON;
    SET @Busqueda = LTRIM(RTRIM(ISNULL(@Busqueda, N'')));
    SELECT id, Titulo, Autor, CantidadDisponible, Categoria
    FROM dbo.Libros
    WHERE @Busqueda = N''
        OR CHARINDEX(@Busqueda, Titulo) > 0
        OR CHARINDEX(@Busqueda, Autor) > 0
        OR CHARINDEX(@Busqueda, Categoria) > 0
        OR CONVERT(NVARCHAR(11), id) = @Busqueda
    ORDER BY Titulo, id;
END;
GO
CREATE OR ALTER PROCEDURE dbo.usp_Libros_Agregar
    @Titulo NVARCHAR(200),
    @Autor NVARCHAR(150),
    @CantidadDisponible INT,
    @Categoria NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @Titulo = LTRIM(RTRIM(@Titulo));
    SET @Autor = LTRIM(RTRIM(@Autor));
    IF @Titulo IS NULL OR LEN(@Titulo) = 0
        THROW 50001, N'El título del libro es obligatorio.', 1;
    IF @Autor IS NULL OR LEN(@Autor) = 0
        THROW 50002, N'El autor del libro es obligatorio.', 1;
    IF @CantidadDisponible IS NULL OR @CantidadDisponible < 0
        THROW 50003, N'La cantidad debe ser un entero mayor o igual a cero.', 1;
    IF @Categoria IS NULL OR @Categoria NOT IN
        (N'Novela', N'Ciencia ficción', N'Fantasía', N'Historia', N'Otros')
        THROW 50004, N'Selecciona una categoría válida.', 1;

    INSERT INTO dbo.Libros (Titulo, Autor, CantidadDisponible, Categoria)
    VALUES (@Titulo, @Autor, @CantidadDisponible, @Categoria);
    SELECT CONVERT(INT, SCOPE_IDENTITY()) AS id;
END;
GO
CREATE OR ALTER PROCEDURE dbo.usp_Libros_ActualizarCantidad
    @Id INT,
    @CantidadDisponible INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF @CantidadDisponible IS NULL OR @CantidadDisponible < 0
        THROW 50003, N'La cantidad debe ser un entero mayor o igual a cero.', 1;
    UPDATE dbo.Libros SET CantidadDisponible = @CantidadDisponible WHERE id = @Id;
    IF @@ROWCOUNT = 0
        THROW 50005, N'El libro ya no existe. Actualiza el inventario e intenta nuevamente.', 1;
END;
GO
CREATE OR ALTER PROCEDURE dbo.usp_Libros_Eliminar
    @Id INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DELETE FROM dbo.Libros WHERE id = @Id;
    IF @@ROWCOUNT = 0
        THROW 50005, N'El libro ya no existe. Actualiza el inventario e intenta nuevamente.', 1;
END;
GO
